<ECE 573 Project Step1>

Ning Ding
Hyun Dok Cho

1. Instructions
  1.1 $make
  1.2 $./scanner < fibonacci.micro > fibonacci.output
  1.3 $diff
	
   
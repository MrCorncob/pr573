<ECE 573 Project Step4>

Ning Ding
Hyun Dok Cho

1. Expected Behavior of Your Makefile
  1.1 Printing your (and your partner's) ID
		$ make group
  1.2 Cleaning all generated files
		$ make clean
  1.3 Building your compiler
		$ make all
2. Expected Behavior of Your Compiler
 		$ java -cp lib/antlr-3.3-complete.jar:classes Micro path_to_your_testcases/test.micro
	

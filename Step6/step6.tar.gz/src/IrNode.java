public class IrNode {
	public IrNode() {};
	public IrNode(String ir){
		irCode = ir;
	}
	public String irCode;
	public String[] tinycode;
	public IrNode jumpto;
	
}
